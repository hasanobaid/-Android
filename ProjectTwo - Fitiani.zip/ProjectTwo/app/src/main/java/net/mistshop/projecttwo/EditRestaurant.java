package net.mistshop.projecttwo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceCategory;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.Toast;

import com.google.gson.Gson;


public class EditRestaurant extends AppCompatActivity {
    private ImageView img;
    private EditText name;
    private EditText desc;
    private RatingBar ratingBar;
    private SharedPreferences prefs;
    private SharedPreferences.Editor prefsEditor;
    private int position;
    private int currentIMG;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_restaurant);
        Intent intent = getIntent();

        img = (ImageView) findViewById(R.id.img);
        name = (EditText) findViewById(R.id.editName);
        desc = (EditText) findViewById(R.id.editDesc);
        ratingBar = (RatingBar) findViewById(R.id.editRating);
        currentIMG = intent.getIntExtra("IMG",0);

        img.setImageResource(currentIMG);
        name.setText(intent.getStringExtra("NAME"));
        desc.setText(intent.getStringExtra("DESC"));
        ratingBar.setRating(intent.getIntExtra("RATE",0));
        position = intent.getIntExtra("POS",0);

        prefs = getSharedPreferences("PREFS",MODE_PRIVATE);
        prefsEditor = prefs.edit();

    }

    public void saveOnClick(View view){
        if(desc.getText().toString().isEmpty() || name.getText().toString().isEmpty()){
            Toast.makeText(this,"Please fill all fields",Toast.LENGTH_SHORT).show();
        }
        else {
            Gson gson = new Gson();
            String loadData = prefs.getString("SAVEDATA", null);
            Restaurant[] rests = gson.fromJson(loadData, Restaurant[].class);
            rests[position].setName(name.getText().toString());
            rests[position].setDescription(desc.getText().toString());
            rests[position].setRating((int) ratingBar.getRating());
            rests[position].setImageID(currentIMG);
            String saveRestaurantsJSON = gson.toJson(rests);
            prefsEditor.putString("SAVEDATA", saveRestaurantsJSON);
            prefsEditor.commit();

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
        }
    }
}
