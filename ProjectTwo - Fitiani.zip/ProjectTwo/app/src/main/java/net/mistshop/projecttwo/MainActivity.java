package net.mistshop.projecttwo;

import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;

import com.google.gson.Gson;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recycler;
    private SharedPreferences prefs;
    private SharedPreferences.Editor prefsEditor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("PREFS",MODE_PRIVATE);
        prefsEditor = prefs.edit();
        Gson gson = new Gson();

        String savedData = prefs.getString("SAVEDATA",null);
        Restaurant[] rests;
        if(savedData == null ) {
            rests = initRestaurantArray();
        }
        else {
            rests = gson.fromJson(savedData,Restaurant[].class);
        }

        Log.d("FIRST",R.drawable.ic_launcher_background+"");
        Log.d("SECOND",rests[0].getImageID()+"");




        recycler = (RecyclerView) findViewById(R.id.recyclerView);

        String[] names = new String[rests.length];
        String[] descs = new String[rests.length];
        int[] ratings = new int[rests.length];
        int[] imageIDs = new int[rests.length];

        for (int i = 0; i < rests.length; i++) {
            names[i] = rests[i].getName();
            descs[i] = rests[i].getDescription();
            ratings[i] = rests[i].getRating();
            imageIDs[i] = rests[i].getImageID();
        }

        recycler.setLayoutManager(new LinearLayoutManager(this));
        RestCard adapter = new RestCard(names, descs, ratings, imageIDs);
        recycler.setAdapter(adapter);

    }

    public Restaurant[] initRestaurantArray(){
        Restaurant[] array = new Restaurant[]{
                new Restaurant("McDonalds", "Fast Food", 2, R.drawable.logo_mc),
                new Restaurant("Black Wok", "Sushi", 4, R.drawable.logo_wok),
                new Restaurant("Firefly Burger", "Burgers", 4, R.drawable.logo_ff),
                new Restaurant("Toasty", "Shawarma", 5, R.drawable.logo_toast),
                new Restaurant("KFC", "Fast Food", 3, R.drawable.logo_kfc),
                new Restaurant("Hardee's", "Fast Food", 3, R.drawable.logo_hardees),
        };
        return array;

    }
}
